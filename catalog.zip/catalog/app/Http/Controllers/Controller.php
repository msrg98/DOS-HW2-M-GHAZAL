<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Storage;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function search(Request $request)
    {
        $file = fopen(storage_path("databases/database.txt"), "r");
        $result = collect([]);
        while (!feof($file)) {
            $item = fgets($file);
            $itemArray = explode(',', $item);
            if ($itemArray[4] === $request->input('topic'))
                $result->push(['id' => $itemArray[0], 'title' => $itemArray[1]]);
        }
        fclose($file);
        echo json_encode($result);
    }

    public function lookUp(Request $request)
    {
        $file = fopen(storage_path("databases/database.txt"), "r");
        $result = collect([]);
        while (!feof($file)) {
            $item = fgets($file);
            $itemArray = explode(',', $item);
            if (intval($itemArray[0]) === intval($request->input('id'))) {
                echo json_encode(['id' => $itemArray[0], 'title' => $itemArray[1], 'stock' => $itemArray[2], 'price' => $itemArray[3], 'topic' => $itemArray[4]]);
                break;
            }
        }
        fclose($file);
    }

    public function buy(Request $request)
    {
        $file = fopen(storage_path("databases/database.txt"), "r+");
        $result = collect([]);
        $lineNo = 0;
        $newText = "";
        while (!feof($file)) {
            $lineNo++;
            $item = fgets($file);
            $itemArray = explode(',', $item);
            if (intval($itemArray[0]) === intval($request->input('id'))) {
                if (intval($itemArray[2]) > 0) {
                    $newStock = intval($itemArray[2])-1;
                    $newText = $newText.$itemArray[0].",".$itemArray[1].",".$newStock.",".$itemArray[3].",".$itemArray[4]."\n";
                    $writeFlag = true;
                }
                else
                    $newText = $newText.$item."\n";
                    $writeFlag = false;
                break;
            }
            else {
                $newText = $newText.$item."\n";
            }
        }
        fwrite($file,$newText);
        fclose($file);
        if ($writeFlag){
            echo json_encode("success");
        }
        else
            echo json_encode("failed");
    }
}
